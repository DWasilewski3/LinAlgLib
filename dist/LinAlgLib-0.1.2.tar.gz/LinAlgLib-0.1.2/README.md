Install command: pip install --index-url https://test.pypi.org/simple/ LinAlgLib
