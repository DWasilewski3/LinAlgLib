Install command:     pip install --index-url https://test.pypi.org/simple/ LinAlgLib
Update command:      pip install --index-url https://test.pypi.org/simple/ --upgrade LinAlgLib
Uninstall command:   pip uninstall LinAlgLib

import LinAlgLib.functions as lal